﻿namespace Plus.Communication.Interfaces
{
    public interface IServerPacket
    {
        byte[] GetBytes();
    }
}